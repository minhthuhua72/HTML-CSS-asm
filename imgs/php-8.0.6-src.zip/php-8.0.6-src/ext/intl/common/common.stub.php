<?php

/** @generate-function-entries */

class IntlIterator implements Iterator
{
    /** @return mixed */
    public function current() {}

    /** @return mixed */
    public function key() {}

    /** @return void */
    public function next() {}

    /** @return void */
    public function rewind() {}

    /** @return bool */
    public function valid() {}
}
